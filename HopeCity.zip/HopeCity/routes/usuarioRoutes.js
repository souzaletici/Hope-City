const express = require ("express")
const {cadastroUsuario} = require ("../controllers/usuarioController")

const route = express.Router ()
router.post ("/cadastroUsuario", cadastroUsuario)

module.exports = router;




