const Feedback = require('../Models/modFeedback');

module.exports = {

  async criar(req, res) {
    const { idVoluntario, idInstituicao, nota, comentario } = req.body;
    if (!idVoluntario || !idInstituicao || !nota) return res.status(400).json({ error: 'Campos obrigatórios faltando.' });

    try {
      const feedback = await Feedback.create({ idVoluntario, idInstituicao, nota, comentario });
      res.status(201).json(feedback);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao criar feedback.', details: err.message });
    }
  },

  async listar(req, res) {
    try {
      const feedbacks = await Feedback.findAll();
      res.json(feedbacks);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao listar feedbacks.', details: err.message });
    }
  },

  async atualizar(req, res) {
    const { id } = req.params;
    const { nota, comentario } = req.body;

    try {
      const feedback = await Feedback.findByPk(id);
      if (!feedback) return res.status(404).json({ error: 'Feedback não encontrado.' });

      await feedback.update({ nota, comentario });
      res.json({ message: 'Feedback atualizado com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao atualizar feedback.', details: err.message });
    }
  },

  async excluir(req, res) {
    const { id } = req.params;

    try {
      const feedback = await Feedback.findByPk(id);
      if (!feedback) return res.status(404).json({ error: 'Feedback não encontrado.' });

      await feedback.destroy();
      res.json({ message: 'Feedback excluído com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao excluir feedback.', details: err.message });
    }
  }

};
