const Inscricao = require('../Models/modInscricao');

module.exports = {

  async criar(req, res) {
    const { idVoluntario, idVaga } = req.body;
    if (!idVoluntario || !idVaga) return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });

    try {
      const existente = await Inscricao.findOne({ where: { idVoluntario, idVaga } });
      if (existente) return res.status(409).json({ error: 'Voluntário já inscrito nesta vaga.' });

      const inscricao = await Inscricao.create({ idVoluntario, idVaga });
      res.status(201).json(inscricao);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao criar inscrição.', details: err.message });
    }
  },

  async listar(req, res) {
    try {
      const inscricoes = await Inscricao.findAll();
      res.json(inscricoes);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao listar inscrições.', details: err.message });
    }
  },

  async atualizar(req, res) {
    const { id } = req.params;
    const { idVoluntario, idVaga } = req.body;

    try {
      const inscricao = await Inscricao.findByPk(id);
      if (!inscricao) return res.status(404).json({ error: 'Inscrição não encontrada.' });

      await inscricao.update({ idVoluntario, idVaga });
      res.json({ message: 'Inscrição atualizada com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao atualizar inscrição.', details: err.message });
    }
  },

  async excluir(req, res) {
    const { id } = req.params;

    try {
      const inscricao = await Inscricao.findByPk(id);
      if (!inscricao) return res.status(404).json({ error: 'Inscrição não encontrada.' });

      await inscricao.destroy();
      res.json({ message: 'Inscrição excluída com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao excluir inscrição.', details: err.message });
    }
  }

};
