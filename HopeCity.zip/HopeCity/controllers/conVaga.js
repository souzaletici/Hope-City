const Vaga = require('../Models/modVaga');

module.exports = {
    
  async criar(req, res) {
    const { titulo, descricao, area, idInstituicao } = req.body;
    if (!titulo || !descricao || !area || !idInstituicao) return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });

    try {
      const vaga = await Vaga.create({ titulo, descricao, area, idInstituicao });
      res.status(201).json(vaga);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao criar vaga.', details: err.message });
    }
  },

  async listar(req, res) {
    try {
      const vagas = await Vaga.findAll();
      res.json(vagas);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao listar vagas.', details: err.message });
    }
  },

  async atualizar(req, res) {
    const { id } = req.params;
    const { titulo, descricao, area } = req.body;

    try {
      const vaga = await Vaga.findByPk(id);
      if (!vaga) return res.status(404).json({ error: 'Vaga não encontrada.' });

      await vaga.update({ titulo, descricao, area });
      res.json({ message: 'Vaga atualizada com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao atualizar vaga.', details: err.message });
    }
  },

  async excluir(req, res) {
    const { id } = req.params;

    try {
      const vaga = await Vaga.findByPk(id);
      if (!vaga) return res.status(404).json({ error: 'Vaga não encontrada.' });

      await vaga.destroy();
      res.json({ message: 'Vaga excluída com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao excluir vaga.', details: err.message });
    }
  }

};
