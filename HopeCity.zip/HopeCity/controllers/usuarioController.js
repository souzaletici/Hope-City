const bcrypt = require ("bcrypt")
const Usuario = require ("../models/Usuario")
const cadastroUsuario = (req, res ) => {
    const {nome, email, senha} = req.body;
    if (!nome || !email|| !senha) {
        return res.status (404).json ({erros: "Todos os campos são obrigatórios"})
    }

    Usuario.findOne({where:{email}})
    .then (usuarioExistente =>{
        if(usuarioExistente){
            throw{status:400, message:"Email já cadastrado"}
        }
        return bcrypt.hash(String(senha), 10)
    })
    .then((senhaHash)=>{
        return Usuario.create({nome, email, senha:senhaHash});
    })
    .then((novoUsuario) =>{
        res.status (201).json ({messge:"Usuario cadastrado com sucesso", usuario: novoUsuario})
    })
    .catch ((error) =>{
        if (error.status){
            return res.status (error.status).json({error: error.message})
        }
        console.log("Erro ao cadastrar usuário: ", error)
        res.status(500).json({eror:"Erro interno do servidor"})       
    })
}
modele.exports = {cadastroUsuario}