const Voluntario = require('../Models/modVoluntario');
const bcrypt = require('bcrypt');

module.exports = {

  // Criar voluntário
  async criar(req, res) {
    const { nome, email, senha, cpf } = req.body;
    if (!nome || !email || !senha || !cpf) return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });

    try {
      const existente = await Voluntario.findOne({ where: { email } });
      if (existente) return res.status(409).json({ error: 'Email já cadastrado.' });

      const senhaHash = await bcrypt.hash(senha, 10);
      const voluntario = await Voluntario.create({ nome, email, senha: senhaHash, cpf });

      res.status(201).json({ id: voluntario.id, nome: voluntario.nome, email: voluntario.email });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao criar voluntário.', details: err.message });
    }
  },

  // Listar todos
  async listar(req, res) {
    try {
      const voluntarios = await Voluntario.findAll({ attributes: ['id','nome','email','cpf'] });
      res.json(voluntarios);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao listar voluntários.', details: err.message });
    }
  },

  // Atualizar voluntário
  async atualizar(req, res) {
    const { id } = req.params;
    const { nome, email, senha, cpf } = req.body;

    try {
      const voluntario = await Voluntario.findByPk(id);
      if (!voluntario) return res.status(404).json({ error: 'Voluntário não encontrado.' });

      if (senha) {
        req.body.senha = await bcrypt.hash(senha, 10);
      }

      await voluntario.update({ nome, email, senha: req.body.senha, cpf });
      res.json({ message: 'Voluntário atualizado com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao atualizar voluntário.', details: err.message });
    }
  },

  // Excluir voluntário
  async excluir(req, res) {
    const { id } = req.params;

    try {
      const voluntario = await Voluntario.findByPk(id);
      if (!voluntario) return res.status(404).json({ error: 'Voluntário não encontrado.' });

      await voluntario.destroy();
      res.json({ message: 'Voluntário excluído com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao excluir voluntário.', details: err.message });
    }
  }

};
