const Instituicao = require('../Models/modInstituicao');
const bcrypt = require('bcrypt');

module.exports = {

  async criar(req, res) {
    const { nome, email, senha, cnpj, telefone, cidade } = req.body;
    if (!nome || !email || !senha || !cnpj || !cidade) return res.status(400).json({ error: 'Campos obrigatórios faltando.' });

    try {
      const existente = await Instituicao.findOne({ where: { email } });
      if (existente) return res.status(409).json({ error: 'Email já cadastrado.' });

      const senhaHash = await bcrypt.hash(senha, 10);
      const instituicao = await Instituicao.create({ nome, email, senha: senhaHash, cnpj, telefone, cidade });

      res.status(201).json({ id: instituicao.id, nome: instituicao.nome, email: instituicao.email });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao criar instituição.', details: err.message });
    }
  },

  async listar(req, res) {
    try {
      const instituicoes = await Instituicao.findAll({ attributes: ['id','nome','email','cnpj','cidade','telefone'] });
      res.json(instituicoes);
    } catch (err) {
      res.status(500).json({ error: 'Erro ao listar instituições.', details: err.message });
    }
  },

  async atualizar(req, res) {
    const { id } = req.params;
    const { nome, email, senha, cnpj, telefone, cidade } = req.body;

    try {
      const instituicao = await Instituicao.findByPk(id);
      if (!instituicao) return res.status(404).json({ error: 'Instituição não encontrada.' });

      if (senha) {
        req.body.senha = await bcrypt.hash(senha, 10);
      }

      await instituicao.update({ nome, email, senha: req.body.senha, cnpj, telefone, cidade });
      res.json({ message: 'Instituição atualizada com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao atualizar instituição.', details: err.message });
    }
  },

  async excluir(req, res) {
    const { id } = req.params;

    try {
      const instituicao = await Instituicao.findByPk(id);
      if (!instituicao) return res.status(404).json({ error: 'Instituição não encontrada.' });

      await instituicao.destroy();
      res.json({ message: 'Instituição excluída com sucesso.' });
    } catch (err) {
      res.status(500).json({ error: 'Erro ao excluir instituição.', details: err.message });
    }
  }

};
