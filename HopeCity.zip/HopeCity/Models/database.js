const sequelize = require('sequelize')
const connection = new sequelize('Hope_City','root','escola',{
    host: 'localhost',
    dialect: 'mysql',
    logging: false
});

module.exports = connection