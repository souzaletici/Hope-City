const Sequelize = require('sequelize');
const connection = require('../database');
const Instituicao = require('./Instituicao');

const Vaga = connection.define('vaga', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  titulo: {
    type: Sequelize.STRING(100),
    allowNull: false
  },
  descricao: {
    type: Sequelize.TEXT,
    allowNull: false
  },
  area: {
    type: Sequelize.STRING(50),
    allowNull: false
  },
  idInstituicao: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Instituicao,
      key: 'id'
    }
  }
});

Vaga.sync({force: false}).then(() => {console.log("Tabela Vaga criada")});

module.exports = Vaga;
