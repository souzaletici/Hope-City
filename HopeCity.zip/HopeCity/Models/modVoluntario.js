const Sequelize = require('sequelize');
const connection = require('../database');

const Voluntario = connection.define('voluntario', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  nome: {
    type: Sequelize.STRING(255),
    allowNull: false
  },
  email: {
    type: Sequelize.STRING(255),
    allowNull: false,
    unique: true,
    validate: { isEmail: true }
  },
  senha: {
    type: Sequelize.STRING(255),
    allowNull: false
  },
  cpf: {
    type: Sequelize.STRING(11),
    allowNull: false,
    unique: true,
    validate: {
      isNumeric: true,
      len: [11,11]
    }
  }
});

Voluntario.sync({force: false}).then(() => {console.log("Tabela Voluntario criada")});

module.exports = Voluntario;
