const Sequelize = require('sequelize');
const connection = require('../database');

const Instituicao = connection.define('instituicao', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  nome: {
    type: Sequelize.STRING(255),
    allowNull: false
  },
  email: {
    type: Sequelize.STRING(255),
    allowNull: false,
    unique: true,
    validate: { isEmail: true }
  },
  senha: {
    type: Sequelize.STRING(255),
    allowNull: false
  },
  cnpj: {
    type: Sequelize.STRING(14),
    allowNull: false,
    unique: true,
    validate: {
      isNumeric: true,
      len: [14,14]
    }
  },
  telefone: {
    type: Sequelize.STRING(15),
    allowNull: true
  },
  cidade: {
    type: Sequelize.STRING(255),
    allowNull: false
  }
});

Instituicao.sync({force: false}).then(() => {console.log("Tabela Instituicao criada")});

module.exports = Instituicao;
