const Sequelize = require('sequelize');
const connection = require('../database');
const Voluntario = require('./Voluntario');
const Vaga = require('./Vaga');

const Inscricao = connection.define('inscricao', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  idVoluntario: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Voluntario,
      key: 'id'
    }
  },
  idVaga: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Vaga,
      key: 'id'
    }
  }
}, {
  indexes: [
    {
      unique: true,
      fields: ['idVoluntario','idVaga']
    }
  ]
});

Inscricao.sync({force: false}).then(() => {console.log("Tabela Inscricao criada")});

module.exports = Inscricao;
