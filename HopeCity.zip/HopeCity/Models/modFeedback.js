const Sequelize = require('sequelize');
const connection = require('../database');
const Voluntario = require('./Voluntario');
const Instituicao = require('./Instituicao');

const Feedback = connection.define('feedback', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  idVoluntario: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Voluntario,
      key: 'id'
    }
  },
  idInstituicao: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Instituicao,
      key: 'id'
    }
  },
  nota: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  comentario: {
    type: Sequelize.TEXT,
    allowNull: true
  }
});

Feedback.sync({force: false}).then(() => {console.log("Tabela Feedback criada")});

module.exports = Feedback;
