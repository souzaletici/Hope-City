const Sequelize = require('sequelize');
const connection = require('../database');

const Recrutador = connection.define('usuario', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true, 
        primaryKey: true,
        allowNull: false 
    },
    nome: {
        type: Sequelize.STRING(255),
        allowNull: false,
        validate: {
            notEmpty: true,
            len: [3, 255]
        }
    },
    cnpj: {
      type: Sequelize.STRING(14),
      allowNull: false,
      unique: true,
      validate: {
        isNumeric: true,
        len: [14, 14]
      }
    },
    telefone: {
      type: Sequelize.STRING(15),
      allowNull: true,
      validate: {
        is: /^[0-9]{10,15}$/
      }
    },
    email: {
      type: Sequelize.STRING(255),
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    cidade: {
        type: Sequelize.STRING(255),
        allowNull: false
    }
});

Recrutador.sync({force: false}).then(() => {console.log("tabela criada")})
module.exports = Recrutador;