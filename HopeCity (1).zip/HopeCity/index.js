const express = require('express')
const app = express()
const bodyParser = require('./Models/database')
const usuario = require('./Models/Usuario')
const connection = require("./Models/database")

connection
    .authenticate()
    .then(() => {
        console.log('Conexão feita com sucesso!')
    })
    .catch ((msgError) => {
        console.log(msgError)
    });

app.listen(8080,() => {
    console.log('Rodando')
})