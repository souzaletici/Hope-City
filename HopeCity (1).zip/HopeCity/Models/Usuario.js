const Sequelize = require('sequelize');
const connection = require('./database');

const Usuario = connection.define('usuario', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true, 
        primaryKey: true,
        allowNull: false 
    },
    nome: {
        type: Sequelize.STRING(255),
        allowNull: false,
        validate: {
            notEmpty: true,
            len: [3, 255]
        }
    },
    cpf: {
      type: Sequelize.STRING(11),
      allowNull: false,
      unique: true,
      validate: {
        isNumeric: true,
        len: [11, 11]
      }
    },
    telefone: {
      type: Sequelize.STRING(15),
      allowNull: true,
      validate: {
        is: /^[0-9]{10,15}$/
      }
    },
    email: {
      type: Sequelize.STRING(255),
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    idade: {
      type: Sequelize.INTEGER,
      allowNull: false,
      validate: {
        min: 18,
        max: 120
      }
    },
    genero: {
      type: Sequelize.STRING(50),
      allowNull: true,
      validate: {
        isIn: [['masculino', 'feminino', 'outro']]
      }
    },
    tipo: {
      type: Sequelize.STRING(20),
      allowNull: false,
      validate: {
        isIn: [['voluntário', 'administrador']]
      }
    },
    cidade: {
      type: Sequelize.STRING(255),
      allowNull: false
    }
});

Usuario.sync({force: false}).then(() => {console.log("tabela criada")})
module.exports = Usuario;
