const Sequelize = require('sequelize');
const connection = require('./database');

const Vagas = connection.define('usuario', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true, 
    primaryKey: true,
    allowNull: false 
  },
  escricao: {
    type: Sequelize.STRING(255),
    allowNull: false,
  },
  dia: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW,
  },
  // recrutadorId: { 
  //   type: Sequelize.INTEGER,
  //   references: {
  //     model: Recrutador,  
  //     key: 'id', 
  //   },
  //   allowNull: false,
  // },
  telefone: {  
    type: Sequelize.STRING(15),
    allowNull: true,  
    validate: {
      is: /^[0-9]{10,15}$/
    }
  }
});

Vagas.sync({force: false}).then(() => {console.log("tabela criada")})
module.exports = Vagas;